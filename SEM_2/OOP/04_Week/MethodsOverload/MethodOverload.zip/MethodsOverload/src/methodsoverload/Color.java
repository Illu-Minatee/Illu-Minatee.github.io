/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package methodsoverload;

/**
 *Special class that enumerate constants
 * with numeric values starting from 0
 * @author kasula
 */
public enum Color {
    BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, GREY    
}
